@extends('Layout.layout')
@section('title','Scann Ticket Report')
@section('content')

<h2> Hello this is Scann Ticket Report PAge </h2>

@endsection