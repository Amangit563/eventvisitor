<footer class="footer py-1" style="background-color:rgb(63, 62, 62); border-top: 1px solid #e9ecef; position: fixed; bottom: 0; width: 100%; z-index: 999;">
    <div class="text-left">
        <p class="mb-0" style="font-family: Arial, sans-serif; font-size: 14px; color: white; font-weight: bold; margin-left:20%;">
            &copy; {{ date('Y') }} Event Visitors Management. All rights reserved.
            <span class="mb-0" style="font-family: Arial, sans-serif; font-size: 12px; color: white; font-weight: bold;">
                Designed and Developed by
                <a href="https://copiousinfo.com" target="_blank" style="color: yellow; text-decoration: none;">Copious Info</a>
            </span>
        </p>
    </div>
</footer>