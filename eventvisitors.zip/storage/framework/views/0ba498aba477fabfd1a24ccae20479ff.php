<?php $__env->startSection('title','Scann Ticket Report'); ?>
<?php $__env->startSection('content'); ?>

<h2> Hello this is Scann Ticket Report PAge </h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u828027654/domains/copiousinfo.com/public_html/eventvisitors/resources/views/Admin Report/ScannTicketReport.blade.php ENDPATH**/ ?>