<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dashboard Panal'); ?></title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/layout.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>
<body>

<!-- Header -->
<header class="header" style="background-color: #3f4041; padding: 10px 20px; border-bottom: 2px solid #ddd;">
    <div class="container-fluid">
        <div class="row align-items-center">
            <!-- Sidebar Toggle Button -->
            <div class="col-4 d-flex align-items-center">
                <button class="btn btn-light" id="toggleSidebar" style="font-size: 18px;">☰</button>
            </div>

            <!-- Admin Dashboard Title -->
            <div class="col-4 text-center">
                <h3 class="m-0 text-light">Event Visitors Management</h3>
            </div>

            <!-- Profile Button -->
            <div class="col-4 text-end">
                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle" type="button" id="profileMenu" data-bs-toggle="dropdown" aria-expanded="false" title="Profile">
                        <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Profile" width="30" class="rounded-circle">
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="profileMenu">
                        <li><a class="dropdown-item" href="#">View Profile</a></li>
                        <li><a class="dropdown-item" href="#">Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#">Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>



    <!-- Sidebar -->
    <nav class="sidebar" id="sidebar">
        <a href="#" class="navbar-brand text-center text-white mb-4">Aman</a>
        <!--<a href="#dashboard">Admin Dashboard Panal</a>-->
        <div class="text-center mt-5">
            <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Profile" width="80" class="rounded-circle">
            <h4 class="text-white">Welcome <br> Back, <b>Aman Kumar</b></h4>
            <p class="text-white">Admin</p>
        </div>
        <a href="<?php echo e(url('/scannticket')); ?>">Users</a>
        <a href="<?php echo e(url('/usercreatepage')); ?>">User Create</a>
        <a href="<?php echo e(url('/manageUser')); ?>">Manage User</a>
        <a href="#settings">Settings</a>
        <a href="<?php echo e(url('/gettickets')); ?>">Reports</a>
        <a href="#logout" class="text-danger">Logout</a>
    </nav>

    <!-- Main Content -->
    <div class="main-content" id="mainContent">
        <div class="container-fluid mt-5 pt-4">
            <h2>Welcome, Aman</h2>
            <p>This is your admin dashboard. Add more widgets, tables, or charts to display relevant data.</p>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <p class="card-text">1,234</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Total Sales</h5>
                            <p class="card-text">$12,345</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Pending Orders</h5>
                            <p class="card-text">45</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('Footer/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

    <!-- Custom JS for Toggle Sidebar -->
    <script>
        const toggleSidebarButton = document.getElementById('toggleSidebar');
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('mainContent');

        toggleSidebarButton.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            mainContent.classList.toggle('collapsed');
        });

        // ********************  Data Table  ****************
        $(document).ready(function() {
            $('#exampleTable').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "lengthMenu": [10, 25, 50, 100, 500],
                "language": {
                    "search": "Search records:",
                    "lengthMenu": "Show _MENU_ entries",
                    "info": "Showing _START_ to _END_ of _TOTAL_ entries"
                }
            });
        });

    </script>
</body>
</html>
<?php /**PATH /home/u828027654/domains/copiousinfo.com/public_html/eventvisitors/resources/views/Layout/layout.blade.php ENDPATH**/ ?>